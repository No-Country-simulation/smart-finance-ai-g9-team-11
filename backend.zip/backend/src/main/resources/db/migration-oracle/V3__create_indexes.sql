CREATE INDEX idx_transacoes_analise
ON transacoes(analise_financeira_id);